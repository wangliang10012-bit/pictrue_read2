// 计算下期还款日期
function calculateNextRepaymentDate() {
    const today = new Date();
    const currentDay = today.getDate();
    let nextMonth = today.getMonth() + 1;
    let nextYear = today.getFullYear();

    if (currentDay >= 27) {
        nextMonth += 1;
        if (nextMonth > 12) {
            nextMonth = 1;
            nextYear += 1;
        }
    }

    return nextYear + "-" + String(nextMonth).padStart(2, '0') + "-27";
}

// 更新时间
function updateTime() {
    const now = new Date();
    const timeString = now.getFullYear() + "-" +
        String(now.getMonth() + 1).padStart(2, '0') + "-" +
        String(now.getDate()).padStart(2, '0') + " " +
        String(now.getHours()).padStart(2, '0') + ":" +
        String(now.getMinutes()).padStart(2, '0');

    const loginTimeEl = document.getElementById('loginTime');
    if (loginTimeEl) {
        loginTimeEl.innerText = "上次登录: " + timeString;
    }
}

// 更新第二页还款日期
function updateRepaymentDate() {
    const dateEl = document.getElementById('nextRepaymentDate');
    if (dateEl) {
        dateEl.innerText = calculateNextRepaymentDate();
    }
}

// 页面加载时初始化
document.addEventListener('DOMContentLoaded', function() {
    updateTime();
    updateRepaymentDate();
    setInterval(updateTime, 60000); // 每分钟更新时间
});

// 跳转页面函数
function navigateTo(page) {
    window.location.href = page;
}
